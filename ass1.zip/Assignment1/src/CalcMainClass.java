import javax.swing.JFrame;

public class CalcMainClass {
	public static void main(String[] args) {
		JFrame win = new AssignmentJFrame();
		win.setVisible(true);

	}	

}



