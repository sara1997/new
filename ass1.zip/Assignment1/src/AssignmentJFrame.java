
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.text.JTextComponent;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;


public class AssignmentJFrame extends JFrame{
	Container mainPane;
	JTextField textField = new JTextField("0");
	
	JButton b1 = new NumberJButton("1");
	JButton b2 = new NumberJButton("2");
	JButton b3 = new NumberJButton("3");
	JButton b4 = new NumberJButton("4");
	JButton b5 = new NumberJButton("5");
	JButton b6 = new NumberJButton("6");
	JButton b7 = new NumberJButton("7");
	JButton b8 = new NumberJButton("8");
	JButton b9 = new NumberJButton("9");
	JButton b0 = new NumberJButton("0");
	JButton bplus = new NumberJButton("+");
	JButton bminus = new NumberJButton("-");
	JButton bdot = new NumberJButton(".");
	JButton bmultiply = new NumberJButton("x");
	JButton bdivide = new NumberJButton("/");
	JButton bAC = new NumberJButton("AC");
	JButton bprocentage = new NumberJButton("%");
	JButton bOpenbracket = new NumberJButton("(");
	JButton bClosebracket = new NumberJButton(")");
	JButton bC = new NumberJButton("C");
	JButton bMplus = new NumberJButton("M+");
	JButton bMminus = new NumberJButton("M-");
	JButton bMR = new NumberJButton("MR");
	JButton bMS = new NumberJButton("MS");
	JButton bMC = new NumberJButton("MC");
	JButton bequals = new NumberJButton("=");
	
	public AssignmentJFrame(){
		super();
		initUI();
		placeComponents();
		bindListeners();
	}

	private void initUI() {
		this.setSize(350, 500);
		this.setTitle("assignment");
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}
	
	private void placeComponents() {
		
		JPanel textPanel = new JPanel(new GridLayout(2,2));
		JPanel mainPanel = new JPanel(new BorderLayout());
	
		mainPane = this.getContentPane();
		mainPane.add(mainPanel);
		
		
		mainPanel.add(textPanel, BorderLayout.NORTH);
		textPanel.add(textField);
		textField.setFont(new Font("Ariel",Font.PLAIN,30));
		textField.setBorder(BorderFactory.createCompoundBorder(
				textField.getBorder(),
				BorderFactory.createEmptyBorder(8,8,8,8)));
		Border border = BorderFactory.createLineBorder(Color.BLUE, 2);
		textField.setBorder(border);
		textField.setBackground(Color.white);



		JPanel buttonPanel = new JPanel(new GridLayout(6,6));
		mainPanel.add(buttonPanel,BorderLayout.CENTER);


		buttonPanel.add(bMC);
		buttonPanel.add(bMS);
		buttonPanel.add(bMR);
		buttonPanel.add(bMminus);
		buttonPanel.add(bMplus);
		buttonPanel.add(bC);
		buttonPanel.add(bAC);
		buttonPanel.add(bprocentage);
		buttonPanel.add(b1);
		buttonPanel.add(b2);
		buttonPanel.add(b3);
		buttonPanel.add(bminus);
		buttonPanel.add(b4);
		buttonPanel.add(b5);
		buttonPanel.add(b6);
		buttonPanel.add(bplus);
		buttonPanel.add(b7);
		buttonPanel.add(b8);
		buttonPanel.add(b9);
		buttonPanel.add(bdivide);
		buttonPanel.add(bdot);
		buttonPanel.add(b0);
		buttonPanel.add(bmultiply);
		buttonPanel.add(bequals);


	}


	private void bindListeners() {


	}
}




