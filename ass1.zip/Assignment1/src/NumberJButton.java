
import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;


public class NumberJButton extends JButton{
	public NumberJButton(String text){
		super(text);
		this.setFont(new Font("Ariel",Font.BOLD,27));
		this.setForeground(Color.BLUE.darker()); 
		this.setBorder(new EtchedBorder(EtchedBorder.LOWERED));

		
		
	}
}
